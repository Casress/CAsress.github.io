

#include "mbed.h"
#include "XNucleo53L0A1.h"

#include "ultrasonic.h"
#include <stdio.h>
Serial pc(USBTX,USBRX);
DigitalOut shdn(p26);
// This VL53L0X board test application performs a range measurement in polling mode
// Use 3.3(Vout) for Vin, p28 for SDA, p27 for SCL, P26 for shdn on mbed LPC1768

//I2C sensor pins


   //Set the trigger pin to D8 and the echo pin to D9
                                        //have updates every .1 seconds and a timeout after 1
                                        //second, and call dist when the distance changes
#define VL53L0_I2C_SDA   p28
#define VL53L0_I2C_SCL   p27
#define VL53L02_I2C_SDA   p9
#define VL53L02_I2C_SCL   p10

static XNucleo53L0A1 *board=NULL;
static XNucleo53L0A1 *board2=NULL;
PwmOut motor(p21);
PwmOut motor2(p22);
DigitalOut motor3(p20);

void dist(int dist)
{
    if (dist <= 250){
        motor3 = 1;
    } else {
        motor3 = 0;
    }
    printf("Distance %d mm\r\n", dist);
}

ultrasonic mu(p6, p7, .1, 1, &dist); 

int main()
{
    int status;
    uint32_t distance;
    DevI2C *device_i2c = new DevI2C(VL53L0_I2C_SDA, VL53L0_I2C_SCL);

    int status2;
    uint32_t distance2;
    DevI2C *device_i2c2 = new DevI2C(VL53L02_I2C_SDA, VL53L02_I2C_SCL);

    /* creates the 53L0A1 expansion board singleton obj */
    board = XNucleo53L0A1::instance(device_i2c, A2, D8, D2);
    board2 = XNucleo53L0A1::instance(device_i2c2, A2, D8, D2);
    shdn = 0; //must reset sensor for an mbed reset to work
    wait(0.1);
    shdn = 1;
    wait(0.1);
    /* init the 53L0A1 board with default values */
    mu.startUpdates();//start measuring the distance

    status = board->init_board();
    while (status) {
        pc.printf("Failed to init board! \r\n");
        status = board->init_board();
    }

    status2 = board2->init_board();
    while (status2) {
        pc.printf("Failed to init board! \r\n");
        status2 = board2->init_board();
    }


    //loop taking and printing distance
    while (1) {
        //Do something else here
        mu.checkDistance();     //call checkDistance() as much as possible, as this is where
                                //the class checks if dist needs to be called.

        status = board->sensor_centre->get_distance(&distance);
        if (status == VL53L0X_ERROR_NONE) {
            //pc.printf("D=%ld mm\r\n", distance);
        }

        status2 = board2->sensor_centre->get_distance(&distance2);
        if (status2 == VL53L0X_ERROR_NONE) {
            pc.printf("D=%ld mm\r\n", distance2);
        }

        if (distance <= 250) {
            motor = 0.3;
        } else if(distance <= 100) {
            motor = 1;
        } else {
            motor = 0;
        } 

        if (distance2 <= 250) {
            motor2 = 0.3;
        } else if(distance2 <= 100) {
            motor2 = 1;
        } else {
            motor2 = 0;
        } 

    }
}
